﻿namespace finalProject.Models
{
    public class Reservation
    {
        public string fullName { get; set; }
        public string email { get; set; }
        public string date  { get; set; }
        public string time { get; set; }
        public string pnumber { get; set; }
        public string cnumber   { get; set; }
        public string message { get; set; } 
    }
}
