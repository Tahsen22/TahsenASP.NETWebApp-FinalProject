using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace finalProject.Pages
{
    public class MenuModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
