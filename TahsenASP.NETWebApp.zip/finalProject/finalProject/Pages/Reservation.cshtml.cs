using finalProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace finalProject.Pages
{
    public class ReservationModel : PageModel
    {
        [BindProperty]
        public Reservation reservation { get; set; }
        public string welcomeMessage = "";
        public void OnGet()
        {
        }
        public void OnPost()
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=finalProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            string insert = "INSERT INTO [finalProject].[dbo].[reservations] ([fullName],[email],[date],[time],[pnumber],[cnumber],[message]) VALUES (' " + reservation.fullName + " ' , ' " + reservation.email + " ' , ' " + reservation.date + " ' , ' " + reservation.time + " ' , ' " + reservation.pnumber + " ' , ' " + reservation.cnumber + " ' , ' " + reservation.message + " ')";
            SqlCommand insertcmd = new SqlCommand(insert, con);
            con.Open();
            insertcmd.ExecuteNonQuery();
            con.Close();
            welcomeMessage = "Thank you for your Booking with us " + reservation.fullName + "." + " " + "We will reserve your table for " + reservation.pnumber + " " + "Persons" + " " + "on" + " " + reservation.date + "at" + " " + reservation.time + ".";
        }
    }
}
