using finalProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace finalProject.Pages
{
    public class SignupModel : PageModel
    {
        public const string SessionfName = "_fname";
        public const string SessionlName = "_lname";
        public const string SessionEmail = "_email";
        [BindProperty(SupportsGet = true)]
        public string profileError { get; set; }

        [BindProperty(SupportsGet = true)]
        public string message { get; set; }

        [BindProperty]
        public User Guest { get; set; }
        public string singupError = "";
        public string loginError = "";
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            if(Guest.type == "login")
            {
                SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=finalProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                string checkQuery = "SELECT * FROM [finalProject].[dbo].[nguests] WHERE email = ' " + Guest.email + " ' AND password= ' " + Guest.password + " ' ";
                SqlCommand checkcmd = new SqlCommand(checkQuery, con);
                con.Open();
                SqlDataReader reader = checkcmd.ExecuteReader();
                if (reader.Read())
                {
                    Guest.fname = String.Format("{0}", reader[1]);
                    Guest.lname = String.Format("{0}", reader[2]);
                    HttpContext.Session.SetString(SessionfName, Guest.fname);
                    HttpContext.Session.SetString(SessionlName, Guest.lname);
                    HttpContext.Session.SetString(SessionEmail, Guest.email);
                    return RedirectToPage("/Profile");
                } else
                {
                    loginError = "Email or Password is wrong!";
                    return Page();
                }
            } else
            {
                SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=finalProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                string checkQuery = "SELECT * FROM [finalProject].[dbo].[nguests] WHERE email = ' " + Guest.email + " ' ";
                SqlCommand checkcmd = new SqlCommand(checkQuery, con);
                con.Open();
                SqlDataReader reader = checkcmd.ExecuteReader();
                if (reader.Read())
                {
                    con.Close();
                    singupError = "The user already has an account.";
                    return Page();
                }
                else
                {
                    con.Close();
                    string insert = "INSERT INTO [finalProject].[dbo].[nguests] ([fname],[lname],[email],[password]) VALUES (' " + Guest.fname + " ' , ' " + Guest.lname + " ' , ' " + Guest.email + " ' , ' " + Guest.password + " ')";
                    SqlCommand insertcmd = new SqlCommand(insert, con);
                    con.Open();
                    insertcmd.ExecuteNonQuery();
                    con.Close();
                    HttpContext.Session.SetString(SessionfName, Guest.fname);
                    HttpContext.Session.SetString(SessionlName, Guest.lname);
                    HttpContext.Session.SetString(SessionEmail, Guest.email);
                    return RedirectToPage("/Profile", new { Guest.fname, Guest.lname });
                }
            }
        }
    }
}
