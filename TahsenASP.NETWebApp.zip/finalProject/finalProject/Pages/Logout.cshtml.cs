using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace finalProject.Pages
{
    public class LogoutModel : PageModel
    {
        public const string SessionfName = "_fname";
        public const string SessionlName = "_lname";
        public const string SessionEmail = "_email";
        public string message = "You have successfully logged out!";
        public IActionResult OnGet()
        {
            HttpContext.Session.SetString(SessionfName, "");
            HttpContext.Session.SetString(SessionlName, "");
            HttpContext.Session.SetString(SessionEmail, "");
            return RedirectToPage("/Signup", new {message} );
        }
    }
}
