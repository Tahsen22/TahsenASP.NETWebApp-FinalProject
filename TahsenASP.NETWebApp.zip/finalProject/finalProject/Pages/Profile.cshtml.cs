using finalProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace finalProject.Pages
{
    public class ProfileModel : PageModel
    {
        public const string SessionfName = "_fname";
        public const string SessionlName = "_lname";
        public const string SessionEmail = "_email";
        [BindProperty(SupportsGet = true)]
        public User Guest { get; set; }
        public string profileError = "For access in PROFILE, you need to sign up or log in first!";
        public string firstName = "";
        public string lastName = "";
        public string Email = "";

        public IActionResult OnGet()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString(SessionEmail)))
            {
                return RedirectToPage("/Signup", new { profileError });
            } else
            {
                firstName = HttpContext.Session.GetString(SessionfName);
                lastName = HttpContext.Session.GetString(SessionlName);
                Email = HttpContext.Session.GetString(SessionEmail);
                return Page();
            }
        }
    }
}
